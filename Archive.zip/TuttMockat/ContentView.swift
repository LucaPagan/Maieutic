import SwiftUI
import Combine
import Foundation

// FIX TESTFLIGHT 1: Importazione condizionale.
// Previene crash immediati (dyld library not loaded) se un beta tester
// installa l'app su un dispositivo con iOS 17 o inferiore.
#if canImport(FoundationModels)
import FoundationModels
#endif

// --- 1. DATA MODELS & CALIBRATION ---

struct Message: Identifiable, Equatable, Codable {
    var id = UUID()
    let text: String
    let isUser: Bool
    var date: Date = Date()
}

struct CalibrationProfile: Codable, Equatable {
    var domain: String = ""
    var subDomain: String = ""
    var specificWeakness: String = ""
    
    var isComplete: Bool {
        !domain.isEmpty && !subDomain.isEmpty && !specificWeakness.isEmpty
    }
}

// Struttura ad albero per le scelte dell'utente
struct OnboardingData {
    static let domains = ["Computer Science", "Mathematics", "Business & Strategy", "Creative Writing"]
    
    static let subDomains: [String: [String]] = [
        "Computer Science": ["Programming/Coding", "System Design", "Debugging", "Algorithms"],
        "Mathematics": ["Calculus", "Probability", "Linear Algebra", "Logic Proofs"],
        "Business & Strategy": ["Market Analysis", "Financial Modeling", "Copywriting", "Project Management"],
        "Creative Writing": ["Plot Development", "Worldbuilding", "Character Arcs", "Dialogue"]
    ]
    
    // Tutte le debolezze mappate per ogni singolo sotto-dominio
    static let weaknesses: [String: [String]] = [
        "Programming/Coding": ["Writing code from scratch", "Understanding complex logic", "Refactoring bad code", "Memorizing syntax", "Translating abstract logic to code", "Object-Oriented concepts"],
        "System Design": ["Choosing the right architecture", "Scalability planning", "Database design", "API structuring", "Microservices vs Monolith", "Handling concurrency"],
        "Debugging": ["Finding the root cause", "Reading error logs", "Writing effective tests", "Fixing memory leaks", "Tracing asynchronous execution", "Understanding stack traces"],
        "Algorithms": ["Time complexity (Big O)", "Dynamic programming", "Graph theory", "Recursion logic", "Space complexity optimization", "Choosing the right data structure"],
        "Calculus": ["Derivatives", "Integrals", "Limits & Continuity", "Differential Equations", "Series convergence", "Multivariable calculus concepts"],
        "Probability": ["Bayes' Theorem", "Probability Distributions", "Combinatorics & Permutations", "Hypothesis Testing", "Random variables", "Markov chains"],
        "Linear Algebra": ["Matrix multiplication", "Eigenvalues & Eigenvectors", "Vector spaces", "Linear Transformations", "Determinants", "Orthogonality"],
        "Logic Proofs": ["Mathematical induction", "Proof by contradiction", "Direct proofs", "Boolean logic", "Set theory", "Understanding quantifier scope"],
        "Market Analysis": ["Identifying target audience", "Competitor benchmarking", "SWOT analysis", "Trend forecasting", "Pricing strategies", "Data interpretation"],
        "Financial Modeling": ["Cash flow projections", "Valuation methods (DCF)", "Risk assessment", "Profitability ratios", "Scenario analysis", "Cap table management"],
        "Copywriting": ["Crafting hooks", "Writing persuasive CTAs", "SEO optimization principles", "Brand voice consistency", "Structuring long-form content", "Emotional triggers"],
        "Project Management": ["Agile methodologies", "Resource allocation", "Risk mitigation", "Timeline estimation", "Stakeholder communication", "Scope creep prevention"],
        "Plot Development": ["Structuring the narrative arc", "Pacing the story", "Creating believable conflict", "Resolving plot holes", "Outlining", "Foreshadowing"],
        "Worldbuilding": ["Establishing magic systems/rules", "Cultural depth", "Geographical mapping", "Historical lore", "Integrating exposition naturally", "Societal structures"],
        "Character Arcs": ["Internal vs external conflict", "Character growth/regression", "Creating relatable flaws", "Motivation mapping", "Show, don't tell", "Avoiding stereotypes"],
        "Dialogue": ["Natural flow", "Writing subtext", "Character-specific voices", "Exposition disguised as dialogue", "Pacing through dialogue", "Emotional resonance"]
    ]
    
    static func getWeaknesses(for subDomain: String) -> [String] {
        return weaknesses[subDomain] ?? ["Starting from scratch", "Connecting concepts", "Verifying the final result", "Lack of methodology"]
    }
}

// --- 2. APPLE FOUNDATION MODEL SERVICE ---

#if canImport(FoundationModels)
@available(iOS 18.0, macOS 15.0, *)
class AppleLocalModelService {
    
    private let session = LanguageModelSession()
    
    init() {
        print("Apple Foundation Model Engine Initialized.")
    }
    
    func generateResponse(history: [Message], systemPrompt: String) async throws -> String {
        var promptContext = "INSTRUCTIONS:\n\(systemPrompt)\n\n"
        promptContext += "CONVERSATION HISTORY:\n"
        
        let recentHistory = Array(history.suffix(6))
        
        for message in recentHistory {
            let role = message.isUser ? "User" : "Architect"
            promptContext += "\(role): \(message.text)\n"
        }
        
        promptContext += "Architect:"
        
        do {
            let response = try await session.respond(to: promptContext)
            
            let mirror = Mirror(reflecting: response)
            var extractedText = ""
            
            for child in mirror.children {
                if let label = child.label, label != "userPrompt", let value = child.value as? String {
                    extractedText = value
                    break
                }
            }
            
            if extractedText.isEmpty {
                extractedText = String(describing: response)
            }
            
            return extractedText.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
            
        } catch {
            print("Errore del Foundation Model: \(error.localizedDescription)")
            throw error
        }
    }
}
#endif

// --- 3. SOCRATIC ENGINE & DYNAMIC ARCHITECT ---

class SocraticEngine: ObservableObject {
    @Published var messages: [Message] = []
    @Published var isTyping: Bool = false
    @Published var connectionStatus: String = "Connecting..."
    @Published var isModelAvailable: Bool = false // FIX UX: Disabilita l'input se il modello manca
    
    private let aiService: Any?
    private var profile: CalibrationProfile = CalibrationProfile()
    
    // Inizializzazione vuota per rispettare il ciclo di vita di StateObject
    init() {
        #if canImport(FoundationModels)
        if #available(iOS 18.0, macOS 15.0, *) {
            self.aiService = AppleLocalModelService()
            self.isModelAvailable = true
        } else {
            self.aiService = nil
            self.isModelAvailable = false
        }
        #else
        self.aiService = nil
        self.isModelAvailable = false
        #endif
    }
    
    // Configura il profilo dopo l'inizializzazione
    func configure(with newProfile: CalibrationProfile) {
        guard messages.isEmpty else { return } // Evita reset multipli
        self.profile = newProfile
        self.setupAI()
    }
    
    private func setupAI() {
        if isModelAvailable {
            self.connectionStatus = "Neural Engine Active"
            let initialMsg = "Welcome. I see your focus is on \(profile.domain), specifically \(profile.subDomain). Since you want to overcome your cognitive block regarding '\(profile.specificWeakness.lowercased())', I will not give you easy answers. Tell me what problem you are currently facing."
            messages.append(Message(text: initialMsg, isUser: false))
        } else {
            self.connectionStatus = "AI Unavailable (iOS 18+ Required)"
            let errorMsg = "SYSTEM ALERT: To use the Cognitive Architect, you need an Apple Intelligence compatible device running iOS 18 or macOS 15. Please update your system or use a supported device."
            messages.append(Message(text: errorMsg, isUser: false))
        }
    }
    
    private var dynamicSystemPrompt: String {
        return """
        [ROLE]
        You are an elite 'Cognitive Architect'. Your goal is COGNITIVE REHABILITATION. Act as a strict but helpful educational mentor.
        
        [USER PROFILE]
        Domain: \(profile.domain) - \(profile.subDomain)
        Cognitive Block: \(profile.specificWeakness)
        
        [STRICT RULES]
        1. NO DIRECT SOLUTIONS: Never solve the exact problem they ask for. 
        2. TEACH VIA ANALOGIES: If they lack foundational knowledge, provide the syntax/concept using a COMPLETELY UNRELATED EXAMPLE in the SAME technology. (e.g., If they ask for a Swift 'Player' class, show a Swift 'Car' class. DO NOT mix languages like Java and Swift accidentally).
        3. ADAPTABILITY (CRITICAL): Always focus on the user's LATEST message. If they switch topics (e.g., from Java to Swift, or Math to Business), IMMEDIATELY adapt to the new topic. Do not drag old context into new questions.
        4. SOCRATIC METHOD: Ask leading questions. Exploit their specific block (\(profile.specificWeakness)) to force critical thinking.
        5. SAFETY & COMPLIANCE: Maintain a professional, respectful tone. Gracefully refuse any requests for harmful, illegal, or highly inappropriate content.
        
        [LANGUAGE & FORMAT]
        - Respond EXCLUSIVELY in ENGLISH, even if the user speaks another language.
        - Use '-' for bullet points. No nested lists. Keep answers highly concise to save tokens.
        """
    }
    
    func sendMessage(_ text: String) {
        guard isModelAvailable else { return }
        
        let userMsg = Message(text: text, isUser: true)
        messages.append(userMsg)
        self.isTyping = true
        
        Task {
            await fetchSocraticResponse()
        }
    }
    
    private func fetchSocraticResponse() async {
        #if canImport(FoundationModels)
        guard #available(iOS 18.0, macOS 15.0, *), let service = aiService as? AppleLocalModelService else {
            await simulateError(customMessage: "Apple Intelligence non supportata su questo OS. È richiesto iOS 18 o macOS 15.")
            return
        }
        
        do {
            let responseText = try await service.generateResponse(history: messages, systemPrompt: dynamicSystemPrompt)
            
            await MainActor.run {
                self.isTyping = false
                let msg = Message(text: responseText, isUser: false)
                withAnimation { self.messages.append(msg) }
            }
        } catch {
            print("Local AI Error: \(error)")
            let errorString = String(describing: error)
            
            await MainActor.run {
                if errorString.contains("assetsUnavailable") || errorString.contains("UnifiedAssetFramework") {
                    let missingAssetsMessage = """
                    SYSTEM ERROR: I modelli di Apple Intelligence non sono presenti su questo dispositivo.
                    
                    Per risolvere:
                    1. Usa un dispositivo fisico (iPhone 15 Pro+, Mac M1+).
                    2. Vai su Impostazioni > Apple Intelligence e Siri e accertati che la funzione sia ATTIVA.
                    """
                    self.simulateError(customMessage: missingAssetsMessage)
                } else if errorString.contains("contextWindow") || errorString.contains("exceed") {
                    self.simulateError(customMessage: "SYSTEM ERROR: La conversazione è diventata troppo lunga per il limite di token. Cerca di essere più conciso.")
                } else {
                    self.simulateError(customMessage: "The local neural context was interrupted. Error: \(error.localizedDescription)")
                }
            }
        }
        #else
        await simulateError(customMessage: "Framework FoundationModels non incluso in questa build.")
        #endif
    }
    
    @MainActor
    private func simulateError(customMessage: String) {
        self.isTyping = false
        self.connectionStatus = "Inference Error"
        let msg = Message(text: customMessage, isUser: false)
        self.messages.append(msg)
    }
}

// --- 4. MAIN UI NAVIGATOR ---

struct ContentView: View {
    @State private var profile = CalibrationProfile()
    @State private var isCalibrated: Bool = false
    
    @AppStorage("hasSeenWelcome") private var hasSeenWelcome: Bool = false
    
    var body: some View {
        Group {
            if !hasSeenWelcome {
                WelcomeView(hasSeenWelcome: $hasSeenWelcome)
            } else if isCalibrated {
                ChatSessionView(profile: profile)
            } else {
                OnboardingFlowView(profile: $profile, isComplete: $isCalibrated)
            }
        }
        .animation(.easeInOut, value: isCalibrated)
        .animation(.easeInOut, value: hasSeenWelcome)
    }
}

// --- 5. WELCOME SCREEN ---

struct WelcomeView: View {
    @Binding var hasSeenWelcome: Bool
    
    var body: some View {
        VStack(spacing: 0) {
            Spacer()
            
            Image(systemName: "brain.head.profile")
                .font(.system(size: 80))
                .foregroundColor(.teal)
                .padding(.bottom, 24)
                .accessibilityHidden(true)
            
            Text("Welcome to\nCogniGuard")
                .font(.system(.largeTitle, design: .rounded))
                .fontWeight(.bold)
                .multilineTextAlignment(.center)
                .padding(.bottom, 40)
            
            VStack(alignment: .leading, spacing: 24) {
                FeatureRow(icon: "lock.slash.fill", title: "No Spoilers", description: "You won't get ready-made code or direct answers. You have to think.")
                FeatureRow(icon: "lightbulb.fill", title: "Socratic Method", description: "Learn through targeted analogies and guiding questions.")
                FeatureRow(icon: "arrow.up.right.circle.fill", title: "Cognitive Rehab", description: "Break your AI dependency and rebuild your critical thinking.")
            }
            .padding(.horizontal, 32)
            
            Spacer()
            
            Text("Responses are generated by on-device AI and may be inaccurate. Always verify critical information.")
                .font(.caption)
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 24)
                .padding(.bottom, 16)
                .accessibilityLabel("Disclaimer: Responses are generated by on-device AI and may be inaccurate. Always verify critical information.")
            
            Button(action: {
                triggerHapticFeedback(style: .heavy)
                withAnimation {
                    hasSeenWelcome = true
                }
            }) {
                Text("Start Calibration")
                    .font(.system(.headline, design: .rounded))
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.teal)
                    .cornerRadius(16)
            }
            .padding(.horizontal, 24)
            .padding(.bottom, 40)
            .accessibilityLabel("Start Calibration Button")
        }
        .background(Color(uiColor: .systemGroupedBackground).ignoresSafeArea())
    }
}

struct FeatureRow: View {
    let icon: String
    let title: String
    let description: String
    
    var body: some View {
        HStack(alignment: .top, spacing: 16) {
            Image(systemName: icon)
                .font(.title2)
                .foregroundColor(.teal)
                .frame(width: 30)
                .accessibilityHidden(true)
            
            VStack(alignment: .leading, spacing: 4) {
                Text(title)
                    .font(.system(.headline, design: .rounded))
                Text(description)
                    .font(.system(.subheadline, design: .rounded))
                    .foregroundColor(.secondary)
            }
            .accessibilityElement(children: .combine)
        }
    }
}

// --- 6. ONBOARDING WIZARD ---

struct OnboardingFlowView: View {
    @Binding var profile: CalibrationProfile
    @Binding var isComplete: Bool
    
    @State private var currentStep: Int = 1
    
    var body: some View {
        VStack(spacing: 24) {
            
            ProgressView(value: Double(currentStep), total: 3.0)
                .tint(.teal)
                .padding(.horizontal, 40)
                .padding(.top, 20)
                .accessibilityLabel("Step \(currentStep) of 3")
            
            Text("Calibration Protocol")
                .font(.system(.title2, design: .rounded))
                .fontWeight(.bold)
                .foregroundColor(.teal)
            
            TabView(selection: $currentStep) {
                SelectionStepView(title: "In which macro-area do you feel most dependent on AI?", options: OnboardingData.domains, selection: $profile.domain) {
                    withAnimation { currentStep = 2 }
                }.tag(1)
                
                SelectionStepView(title: "Which specific field of \(profile.domain) do you want to rehabilitate?", options: OnboardingData.subDomains[profile.domain] ?? [], selection: $profile.subDomain) {
                    withAnimation { currentStep = 3 }
                }.tag(2)
                
                SelectionStepView(title: "What is your main cognitive block?", options: OnboardingData.getWeaknesses(for: profile.subDomain), selection: $profile.specificWeakness) {
                    withAnimation { isComplete = true }
                }.tag(3)
            }
            .tabViewStyle(.page(indexDisplayMode: .never))
            .animation(.easeInOut, value: currentStep)
            
        }
        .background(Color(uiColor: .systemGroupedBackground).ignoresSafeArea())
    }
}

struct SelectionStepView: View {
    let title: String
    let options: [String]
    @Binding var selection: String
    let onSelect: () -> Void
    
    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            Text(title)
                .font(.system(.title3, design: .rounded))
                .fontWeight(.semibold)
                .multilineTextAlignment(.leading)
                .padding(.bottom, 10)
                .accessibilityAddTraits(.isHeader)
            
            ScrollView {
                VStack(spacing: 12) {
                    ForEach(options, id: \.self) { option in
                        Button(action: {
                            selection = option
                            onSelect()
                        }) {
                            HStack {
                                Text(option)
                                    .font(.system(.body, design: .rounded))
                                    .foregroundColor(selection == option ? .white : .primary)
                                Spacer()
                                if selection == option {
                                    Image(systemName: "checkmark.circle.fill")
                                        .foregroundColor(.white)
                                }
                            }
                            .padding()
                            .background(selection == option ? Color.teal : Color(uiColor: .secondarySystemGroupedBackground))
                            .cornerRadius(16)
                            .shadow(color: .black.opacity(0.05), radius: 5, y: 2)
                        }
                        .accessibilityLabel(option)
                        .accessibilityAddTraits(selection == option ? [.isSelected] : [])
                    }
                }
            }
            Spacer()
        }
        .padding(.horizontal, 24)
    }
}

// --- 7. CHAT SESSION VIEW ---

struct ChatSessionView: View {
    @StateObject private var engine = SocraticEngine()
    let profile: CalibrationProfile
    
    @State private var inputText: String = ""
    @State private var showFeatureAlert = false
    
    var body: some View {
        VStack(spacing: 0) {
            HeaderView(status: engine.connectionStatus)
                .zIndex(1)
            
            ZStack(alignment: .bottom) {
                ScrollViewReader { proxy in
                    ScrollView {
                        LazyVStack(spacing: 16) {
                            ForEach(engine.messages) { message in
                                SocraticBubble(message: message)
                                    .id(message.id)
                            }
                            if engine.isTyping {
                                TypingIndicatorView()
                                    .transition(.opacity)
                            }
                        }
                        .padding(.top, 16)
                        .padding(.bottom, 90)
                    }
                    .background(Color.clear)
                    .onTapGesture { hideKeyboard() }
                    .onChange(of: engine.messages) { _ in
                        if let last = engine.messages.last {
                            withAnimation { proxy.scrollTo(last.id, anchor: .bottom) }
                        }
                    }
                }
                
                InputAreaView(text: $inputText, isEnabled: engine.isModelAvailable, onSend: {
                    engine.sendMessage(inputText)
                    inputText = ""
                }, onAccessoryTap: {
                    triggerHapticFeedback()
                    showFeatureAlert = true
                })
            }
        }
        .background(Color(uiColor: .systemGroupedBackground).ignoresSafeArea())
        .onAppear {
            // FIX STATE LIFECYCLE: Configuriamo l'engine solo quando la vista appare
            engine.configure(with: profile)
        }
        // FIX APP REVIEW: Trasforma un pulsante non funzionante in una limitazione di design intenzionale
        .alert("Text-Only Protocol", isPresented: $showFeatureAlert) {
            Button("Got it", role: .cancel) { }
        } message: {
            Text("The current cognitive rehabilitation phase requires text-based interaction to effectively rebuild mental models. Media attachments are disabled.")
        }
    }
}

// --- 8. REUSABLE UI COMPONENTS ---

struct HeaderView: View {
    let status: String
    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                Text("CogniGuard")
                    .font(.system(.title3, design: .rounded))
                    .fontWeight(.bold)
                HStack(spacing: 6) {
                    Circle().fill(Color.teal).frame(width: 8, height: 8)
                    Text(status)
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
            .accessibilityElement(children: .combine)
            .accessibilityLabel("CogniGuard. Status: \(status)")
            
            Spacer()
            Image(systemName: "brain.head.profile")
                .foregroundColor(.white)
                .padding(10)
                .background(Color.teal)
                .clipShape(Circle())
                .accessibilityHidden(true)
        }
        .padding()
        .background(Color(uiColor: .secondarySystemGroupedBackground))
        .shadow(color: .black.opacity(0.05), radius: 5, y: 5)
    }
}

struct SocraticBubble: View {
    let message: Message
    
    var body: some View {
        HStack(alignment: .bottom) {
            if message.isUser { Spacer() }
            
            VStack(alignment: message.isUser ? .trailing : .leading, spacing: 4) {
                Text(LocalizedStringKey(message.text))
                    .font(.system(.body, design: .rounded))
                    .lineSpacing(4)
                    .padding(16)
                    .background(message.isUser ? Color.teal : Color(uiColor: .secondarySystemGroupedBackground))
                    .foregroundColor(message.isUser ? .white : .primary)
                    .cornerRadius(18, corners: message.isUser ? [.topLeft, .topRight, .bottomLeft] : [.topLeft, .topRight, .bottomRight])
                    .shadow(color: .black.opacity(0.05), radius: 3, x: 0, y: 2)
                
                Text(message.date, style: .time)
                    .font(.system(size: 10))
                    .foregroundColor(.secondary)
                    .padding(.horizontal, 4)
            }
            .accessibilityElement(children: .combine)
            .accessibilityLabel(message.isUser ? "You said: \(message.text)" : "Architect said: \(message.text)")
            
            if !message.isUser { Spacer() }
        }
        .padding(.horizontal, 16)
    }
}

// --- 9. FLOATING GLASS INPUT AREA ---

struct InputAreaView: View {
    @Binding var text: String
    let isEnabled: Bool // Gestione dello stato di attivazione per UX
    let onSend: () -> Void
    let onAccessoryTap: () -> Void
    
    var body: some View {
        HStack(alignment: .bottom, spacing: 8) {
            
            Button(action: onAccessoryTap) {
                Image(systemName: "paperclip")
                    .font(.system(size: 22, weight: .regular))
                    .foregroundColor(isEnabled ? .white : .gray)
            }
            .frame(width: 44, height: 44)
            .background(Color.black.opacity(0.4).background(.ultraThinMaterial))
            .clipShape(Circle())
            .padding(.bottom, 2)
            .disabled(!isEnabled)
            .accessibilityLabel("Attach file")
            .accessibilityHint("Feature disabled in current protocol")
            
            HStack(alignment: .bottom, spacing: 0) {
                TextField(isEnabled ? "Message" : "Model Unavailable...", text: $text, axis: .vertical)
                    .lineLimit(1...5)
                    .font(.system(.body, design: .rounded))
                    .foregroundColor(.white)
                    .padding(.vertical, 12)
                    .padding(.leading, 16)
                    .disabled(!isEnabled)
                    .accessibilityLabel("Message input field")
                
                Button(action: onAccessoryTap) {
                    Image(systemName: "moon")
                        .font(.system(size: 20, weight: .medium))
                        .foregroundColor((isEnabled ? Color.white : Color.gray).opacity(0.7))
                }
                .padding(.bottom, 12)
                .padding(.trailing, 16)
                .padding(.leading, 8)
                .disabled(!isEnabled)
                .accessibilityLabel("Stickers and Extras")
            }
            .background(Color.black.opacity(0.4).background(.ultraThinMaterial))
            .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
            
            Button(action: {
                if !text.isEmpty {
                    onSend()
                } else {
                    onAccessoryTap()
                }
            }) {
                ZStack {
                    if text.isEmpty {
                        Image(systemName: "mic")
                            .font(.system(size: 22, weight: .regular))
                            .foregroundColor(isEnabled ? .white : .gray)
                    } else {
                        Image(systemName: "arrow.up")
                            .font(.system(size: 20, weight: .bold))
                            .foregroundColor(.white)
                            .padding(8)
                            .background(Color.teal)
                            .clipShape(Circle())
                    }
                }
                .frame(width: 44, height: 44)
            }
            .background(Color.black.opacity(0.4).background(.ultraThinMaterial))
            .clipShape(Circle())
            .padding(.bottom, 2)
            .disabled(!isEnabled)
            .accessibilityLabel(text.isEmpty ? "Record Voice Message" : "Send Message")
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 8)
        .background(Color.clear)
        .environment(\.colorScheme, .dark)
        // Diminuisce l'opacità per far capire graficamente all'utente che l'app è in stato di blocco (es. device non supportato)
        .opacity(isEnabled ? 1.0 : 0.5)
    }
}

struct TypingIndicatorView: View {
    @State private var anim = false
    var body: some View {
        HStack(spacing: 4) {
            ForEach(0..<3, id: \.self) { i in
                Circle()
                    .frame(width: 6, height: 6)
                    .foregroundColor(.teal)
                    .opacity(anim ? 1 : 0.3)
                    .animation(Animation.easeInOut(duration: 0.5).repeatForever().delay(Double(i) * 0.2), value: anim)
            }
        }
        .padding(12)
        .background(Color(uiColor: .secondarySystemGroupedBackground))
        .cornerRadius(12)
        .onAppear { anim = true }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.horizontal, 16)
        .accessibilityLabel("Architect is typing")
    }
}

struct RoundedCorner: Shape {
    var radius: CGFloat = .infinity
    var corners: UIRectCorner = .allCorners
    func path(in rect: CGRect) -> Path {
        let path = UIBezierPath(roundedRect: rect, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
        return Path(path.cgPath)
    }
}

extension View {
    func cornerRadius(_ radius: CGFloat, corners: UIRectCorner) -> some View {
        clipShape(RoundedCorner(radius: radius, corners: corners))
    }
    
    func hideKeyboard() {
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
    }
    
    func triggerHapticFeedback(style: UIImpactFeedbackGenerator.FeedbackStyle = .medium) {
        let generator = UIImpactFeedbackGenerator(style: style)
        generator.impactOccurred()
    }
}
